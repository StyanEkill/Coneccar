package com.api.Coneccar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConeccarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConeccarApplication.class, args);
	}

}
